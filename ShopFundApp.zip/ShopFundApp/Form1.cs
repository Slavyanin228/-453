﻿using System;
using System.Data;
using System.Windows.Forms;

namespace ShopFundApp
{
    public partial class Form1 : Form
    {
        private DataBaseHelper db;

        public Form1()
        {
            InitializeComponent();
            db = new DataBaseHelper();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            LoadShopsToComboBox();
            
            btnDeliveries_Click(null, null);
        }

        private void LoadShopsToComboBox()
        {
            try
            {
                DataTable shops = db.GetAllShops();
                comboBoxShops.DataSource = shops;
                comboBoxShops.DisplayMember = "ShopName";
                comboBoxShops.ValueMember = "ShopID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки магазинов: {ex.Message}");
            }
        }

        private void btnShops_Click(object sender, EventArgs e)
        {
            ShowTable("Магазины", db.GetAllShops());
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            ShowTable("Поставщики", db.GetAllSuppliers());
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            ShowTable("Товары", db.GetAllProducts());
        }

        private void btnDeliveries_Click(object sender, EventArgs e)
        {
            ShowTable("Поставки", db.GetAllDeliveries());
        }

        private void btnQuery1_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(comboBoxShops.Text) || comboBoxShops.Text == "-- Выберите магазин --")
            {
                MessageBox.Show("Выберите магазин из списка");
                return;
            }

            try
            {
                string selectedShopName = comboBoxShops.Text;

                
                DataTable allShops = db.GetAllShops();

                
                DataRow[] foundShops = allShops.Select($"ShopName = '{selectedShopName}'");

                if (foundShops.Length == 0)
                {
                    MessageBox.Show($"Магазин '{selectedShopName}' не найден в базе данных");
                    return;
                }

                
                int shopId = Convert.ToInt32(foundShops[0]["ShopID"]);

                DataTable result = db.GetDeliveriesToShop(shopId);

                
                if (result.Rows.Count > 0)
                {
                    dataGridView1.DataSource = result;
                    this.Text = $"Учет фонда магазинов - Поставки в магазин: {selectedShopName}";
                }
                else
                {
                    MessageBox.Show($"Нет поставок в магазин '{selectedShopName}'");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnQuery2_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(comboBoxShops.Text) || comboBoxShops.Text == "-- Выберите магазин --")
            {
                MessageBox.Show("Выберите магазин из списка");
                return;
            }

            try
            {
                string selectedShopName = comboBoxShops.Text;

                
                DataTable allShops = db.GetAllShops();

               
                DataRow[] foundShops = allShops.Select($"ShopName = '{selectedShopName}'");

                if (foundShops.Length == 0)
                {
                    MessageBox.Show($"Магазин '{selectedShopName}' не найден в базе данных");
                    return;
                }

               
                int shopId = Convert.ToInt32(foundShops[0]["ShopID"]);

               
                DataTable result = db.GetProductVolumesInShop(shopId);

                
                if (result.Rows.Count > 0)
                {
                    dataGridView1.DataSource = result;
                    this.Text = $"Учет фонда магазинов - Объем товаров в магазине: {selectedShopName}";
                }
                else
                {
                    MessageBox.Show($"Нет данных по товарам в магазине '{selectedShopName}'");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnQuery3_Click(object sender, EventArgs e)
        {
            DataTable result = db.GetTop3MinSuppliers();
            ShowTable("Топ-3 поставщиков с минимальными объемами", result);

            
            string message = "Топ-3 поставщиков с минимальными объемами поставок:\n\n";
            foreach (DataRow row in result.Rows)
            {
                message += $"{row["Поставщик"]}: {row["Общий объем поставок"]} единиц\n";
            }
            MessageBox.Show(message, "Результат запроса 3");
        }

        private void ShowTable(string title, DataTable data)
        {
            if (data != null && data.Rows.Count > 0)
            {
                dataGridView1.DataSource = data;
                this.Text = $"Учет фонда магазинов - {title}";
            }
            else
            {
                MessageBox.Show("Нет данных для отображения", title);
            }
        }

        private void comboBoxShops_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_453BelonosovDataSet1.Shops". При необходимости она может быть перемещена или удалена.
            this.shopsTableAdapter.Fill(this._453BelonosovDataSet1.Shops);

        }
    }
}