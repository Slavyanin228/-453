﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ShopFundApp
{
    public class DataBaseHelper
    {
        private string connectionString;

        public DataBaseHelper()
        {
            connectionString = @"Data Source=sbd\mssql;Initial Catalog=453Belonosov;Integrated Security=True;";
        }

       
        public DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            DataTable table = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    adapter.Fill(table);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка выполнения запроса: {ex.Message}", ex);
            }

            return table;
        }

       
        public int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            int rowsAffected = 0;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    connection.Open();
                    rowsAffected = command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка выполнения команды: {ex.Message}", ex);
            }

            return rowsAffected;
        }

        
        public object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            object result = null;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters);
                    }

                    connection.Open();
                    result = command.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка выполнения скалярного запроса: {ex.Message}", ex);
            }

            return result;
        }

      
        public DataTable GetAllShops()
        {
            string query = "SELECT * FROM Shops ORDER BY ShopName";
            return ExecuteQuery(query);
        }

        public DataTable GetAllSuppliers()
        {
            string query = "SELECT * FROM Suppliers ORDER BY SupplierName";
            return ExecuteQuery(query);
        }

        public DataTable GetAllProducts()
        {
            string query = "SELECT * FROM Products ORDER BY ProductName";
            return ExecuteQuery(query);
        }

        public DataTable GetAllDeliveries()
        {
            string query = @"
                SELECT 
                    d.DeliveryID,
                    sh.ShopName,
                    s.SupplierName,
                    p.ProductName,
                    d.Quantity,
                    d.DeliveryDate,
                    sh.ShopID,
                    s.SupplierID,
                    p.ProductID
                FROM Deliveries d
                JOIN Shops sh ON d.ShopID = sh.ShopID
                JOIN Suppliers s ON d.SupplierID = s.SupplierID
                JOIN Products p ON d.ProductID = p.ProductID
                ORDER BY d.DeliveryDate DESC";
            return ExecuteQuery(query);
        }

        

        public DataTable GetDeliveriesToShop(int shopId)
        {
            string query = @"
                SELECT 
                    s.SupplierName AS 'Поставщик',
                    p.ProductName AS 'Товар',
                    d.Quantity AS 'Количество',
                    d.DeliveryDate AS 'Дата поставки',
                    sh.ShopName AS 'Магазин'
                FROM Deliveries d
                JOIN Suppliers s ON d.SupplierID = s.SupplierID
                JOIN Products p ON d.ProductID = p.ProductID
                JOIN Shops sh ON d.ShopID = sh.ShopID
                WHERE d.ShopID = @ShopID
                ORDER BY d.DeliveryDate DESC";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ShopID", shopId)
            };

            return ExecuteQuery(query, parameters);
        }

        public DataTable GetProductVolumesInShop(int shopId)
        {
            string query = @"
                SELECT 
                    p.ProductName AS 'Товар',
                    SUM(d.Quantity) AS 'Общее количество'
                FROM Deliveries d
                JOIN Products p ON d.ProductID = p.ProductID
                WHERE d.ShopID = @ShopID
                GROUP BY p.ProductName
                ORDER BY SUM(d.Quantity) DESC";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ShopID", shopId)
            };

            return ExecuteQuery(query, parameters);
        }

        public DataTable GetTop3MinSuppliers()
        {
            string query = @"
                SELECT TOP 3
                    s.SupplierName AS 'Поставщик',
                    s.Phone AS 'Телефон',
                    SUM(d.Quantity) AS 'Общий объем поставок'
                FROM Deliveries d
                JOIN Suppliers s ON d.SupplierID = s.SupplierID
                GROUP BY s.SupplierName, s.Phone
                ORDER BY SUM(d.Quantity) ASC";

            return ExecuteQuery(query);
        }

        
        public bool TestConnection()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    return connection.State == ConnectionState.Open;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}